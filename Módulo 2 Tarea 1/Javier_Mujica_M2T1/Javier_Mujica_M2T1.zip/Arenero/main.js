
//JavaScript first Playground

//Exercises 1, 2, 3, 4 & 5

var otherName = "Iniciando JavaScript"
var myName = "javier"
var edad = 34
var ignasiAge=32
var delta=ignasiAge-edad




console.log(otherName+" "+myName)
console.log(delta)
console.log(ignasiAge-edad)

if(edad<21){console.log("You are not older than 21")}
else{console.log("You have the right age to pass")}

if(delta>0){console.log("Ignaci es mayor")}
else if(delta==0){console.log("Ignaci tiene mi edad")}
else{console.log("Ignaci es menor")}






//JavaScript String Functions
//Exercise 1 with recursive method   
const number=123456789;

function rev(n){
    if(n==""){
        return "";}
    else{
        
        return rev(n.toString().substr(1))+n.toString().charAt(0);
    }
               }
   
//Exercise 1 easy method

function reverseNumber(n){
    const convertAndReverse = n.toString().split("").reverse().join("");
    return Number(convertAndReverse);
}

//Exercise 2
function order(x){
    return x.toString().split("").sort().join("");
}

//Exercise 3

function primMay(str){
 
var limpiarEspaciosYSeparar=str.trim()
                               .toLowerCase()
                               .split(" ")
                               .filter(Boolean)
    
    var cadaPalabra=limpiarEspaciosYSeparar.map(palabras=>palabras[0].toUpperCase()+palabras.substr(1))   
return datoCorrecto=cadaPalabra.join(" ")

}

//Exercise 4 

function palabraLarga(str){
    var PalabrasEnArreglo =str.split(" ")
    var mayor = 0
    var indiceMayor
    for(i=0;i<=PalabrasEnArreglo.length-1;i++){
        if(PalabrasEnArreglo[i].length>mayor)
       {mayor=PalabrasEnArreglo[i].length
        indiceMayor=i}
    }

    return PalabrasEnArreglo[indiceMayor]
}





